package com.example.mypremierleague.ui.screen.cart

import com.example.mypremierleague.model.OrderReward

data class CartState(
    val orderReward: List<OrderReward>,
    val totalRequiredPoint: Int
)