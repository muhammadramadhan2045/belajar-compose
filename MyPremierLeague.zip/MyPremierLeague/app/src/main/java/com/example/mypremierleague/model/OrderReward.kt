package com.example.mypremierleague.model

data class OrderReward(
    val reward: Reward,
    val count: Int
)
