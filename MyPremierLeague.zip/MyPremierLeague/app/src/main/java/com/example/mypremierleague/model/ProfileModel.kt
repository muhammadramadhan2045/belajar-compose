package com.example.mypremierleague.model

data class ProfileModel(
    val name: String,
    val description: String,
    val star: String,
    val language: String
)


