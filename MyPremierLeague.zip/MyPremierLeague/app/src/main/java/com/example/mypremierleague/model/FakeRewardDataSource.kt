package com.example.mypremierleague.model

import com.example.mypremierleague.R

object FakeRewardDataSource {
    val dummyRewards = listOf(
        Reward(1, R.drawable.reward_1, "Liverpool Shirt", 6000),
        Reward(2, R.drawable.reward_2, "Manchester City Shirt", 4500),
        Reward(3, R.drawable.reward_3, "Manchester United Shirt", 1000),
        Reward(4, R.drawable.reward_4, "Chelsea Shirt", 1000),
        Reward(5, R.drawable.reward_5, "Arsenal Shirt", 1000),
        Reward(6, R.drawable.reward_6, "Tottenham Shirt", 1000),
        Reward(7, R.drawable.reward_7, "Leicester Shirt", 750),
        Reward(8, R.drawable.reward_8, "Wolves Shirt", 750),
        Reward(9, R.drawable.reward_9, "Newcastle United Shirt", 300),
        Reward(10, R.drawable.reward_10, "West Ham United Shirt", 300),
        Reward(11, R.drawable.reward_11, "Aston Villa Shirt", 300),
        Reward(12, R.drawable.reward_12, "Brighton Shirt", 300),
    )
}