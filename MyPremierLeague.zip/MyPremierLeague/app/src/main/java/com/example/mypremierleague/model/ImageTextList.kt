package com.example.mypremierleague.model

import com.example.mypremierleague.ui.common.DCodeIcon

data class ImageTextList(
    val icon: DCodeIcon,
    val text: String
)